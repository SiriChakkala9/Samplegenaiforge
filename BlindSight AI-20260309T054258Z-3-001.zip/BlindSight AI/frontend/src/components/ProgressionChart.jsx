import React from 'react';

const ProgressionChart = () => {
    return null; // Implemented inside DiagnosisCards for simplicity of pure CSS layout
}
export default ProgressionChart;
