import React from 'react';
import { Activity, Thermometer, ShieldAlert, TrendingUp } from 'lucide-react';

const DiagnosisCards = ({ diagnosis }) => {
    if (!diagnosis) return null;

    const { dr_present, severity, risk_score, progression_trend } = diagnosis;

    const getSeverityColor = (sev) => {
        switch (sev) {
            case 'None': return 'var(--success)';
            case 'Mild': return 'var(--primary)';
            case 'Moderate': return 'var(--warning)';
            case 'Severe': return 'var(--danger)';
            case 'Proliferative': return '#991b1b'; // Darker red
            default: return 'var(--text-muted)';
        }
    };

    const getRiskColor = (risk) => {
        if (risk < 30) return 'var(--success)';
        if (risk < 70) return 'var(--warning)';
        return 'var(--danger)';
    };

    return (
        <div className="card">
            <h2 className="card-title">Diagnostic Multi-Task Output</h2>

            <div className="stats-grid" style={{ marginBottom: '1.5rem' }}>
                <div className="stat-box">
                    <div className="stat-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <Activity size={14} /> DR Detection
                    </div>
                    <div className="stat-value" style={{ color: dr_present ? 'var(--danger)' : 'var(--success)' }}>
                        {dr_present ? "Positive" : "Negative"}
                    </div>
                </div>

                <div className="stat-box">
                    <div className="stat-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <Thermometer size={14} /> Severity Stage
                    </div>
                    <div className="stat-value" style={{ color: getSeverityColor(severity) }}>
                        {severity}
                    </div>
                </div>
            </div>

            <div className="stat-box" style={{ marginBottom: '1.5rem' }}>
                <div className="stat-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <ShieldAlert size={14} /> Blindness Risk Score
                </div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.5rem', marginBottom: '0.25rem' }}>
                    <span className="stat-value" style={{ color: getRiskColor(risk_score) }}>{risk_score}</span>
                    <span style={{ color: 'var(--text-muted)', fontWeight: 500 }}>/ 100</span>
                </div>
                <div className="progress-bg">
                    <div
                        className="progress-fill"
                        style={{ width: `${risk_score}%`, backgroundColor: getRiskColor(risk_score) }}
                    />
                </div>
            </div>

            <div className="stat-box">
                <div className="stat-label" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <TrendingUp size={14} /> Disease Progression (LSTM Forecast)
                </div>
                <div className="stat-value" style={{ fontSize: '1.2rem', color: progression_trend.includes('Increase') ? 'var(--warning)' : 'var(--success)' }}>
                    {progression_trend} Trend
                </div>
            </div>
        </div>
    );
};

export default DiagnosisCards;
