import { useState } from 'react'
import { Eye, FileText, Activity, AlertCircle, ShieldCheck } from 'lucide-react'
import { Link } from 'react-router-dom'
import axios from 'axios'

import ImageUpload from './ImageUpload'
import DiagnosisCards from './DiagnosisCards'
import HeatmapViewer from './HeatmapViewer'
import ClinicalInterpretation from './ClinicalInterpretation'

function Dashboard() {
    const [file, setFile] = useState(null)
    const [loading, setLoading] = useState(false)
    const [result, setResult] = useState(null)
    const [error, setError] = useState(null)

    const handleUpload = async (selectedFile) => {
        setFile(selectedFile)
        setLoading(true)
        setError(null)
        setResult(null)

        if (!selectedFile) {
            setLoading(false);
            return;
        }

        const formData = new FormData()
        formData.append('file', selectedFile)

        try {
            const response = await axios.post('http://localhost:8000/api/v1/analyze', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            })
            setResult(response.data)
        } catch (err) {
            setError(err.response?.data?.detail || "An error occurred during analysis.")
        } finally {
            setLoading(false)
        }
    }

    const handleDownloadReport = () => {
        if (result?.report_url) {
            window.open(`http://localhost:8000${result.report_url}`, '_blank')
        }
    }

    return (
        <div className="app-container">
            <header className="header">
                <Link to="/" style={{ textDecoration: 'none', color: 'inherit' }}>
                    <h1><Eye size={32} /> BlindSight AI – Blindness Detection & DR Progression System</h1>
                </Link>
                <div className="badge info">
                    <ShieldCheck size={16} style={{ marginRight: '4px' }} /> Clinical Grade Pipeline
                </div>
            </header>

            <div className="dashboard-grid">
                {/* Left Column: Upload & Original Image */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    <ImageUpload onUpload={handleUpload} isProcessing={loading} file={file} />
                </div>

                {/* Center Column: Diagnostics & Grad-CAM */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    {loading ? (
                        <div className="card" style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                            <div className="loader"></div>
                            <p style={{ color: 'var(--text-muted)' }}>Running multimodal AI pipeline...</p>
                            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.5rem' }}>ViT Extraction → U-Net Segmentation → LSTM Analysis</p>
                        </div>
                    ) : result ? (
                        <>
                            <DiagnosisCards diagnosis={result.diagnosis} />
                            <HeatmapViewer diagnosis={result.diagnosis} />
                        </>
                    ) : (
                        <div className="card" style={{ flex: 1, alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
                            <Activity size={48} color="var(--border)" style={{ marginBottom: '1rem' }} />
                            <h3 style={{ color: 'var(--text-muted)' }}>Waiting for Image</h3>
                            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', maxWidth: '300px', marginTop: '0.5rem' }}>
                                Upload a retinal fundus scan to run the Intelligent Diagnosis pipeline.
                            </p>
                        </div>
                    )}
                </div>

                {/* Right Column: LLM & Progression */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
                    {error && (
                        <div className="card" style={{ borderColor: 'var(--danger)', backgroundColor: '#fef2f2' }}>
                            <h3 className="card-title" style={{ color: 'var(--danger)' }}><AlertCircle /> Analysis Error</h3>
                            <p>{error}</p>
                        </div>
                    )}

                    {result && (
                        <>
                            <ClinicalInterpretation interpretation={result.interpretation} />
                            <div className="card" style={{ marginTop: 'auto' }}>
                                <button className="btn" style={{ width: '100%' }} onClick={handleDownloadReport}>
                                    <FileText size={18} /> Download Medical PDF Report
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    )
}

export default Dashboard
