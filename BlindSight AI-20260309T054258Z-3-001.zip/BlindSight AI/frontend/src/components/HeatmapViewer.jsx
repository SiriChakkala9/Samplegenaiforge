import React, { useState } from 'react';
import { Layers, Map } from 'lucide-react';

const HeatmapViewer = ({ diagnosis }) => {
    const [view, setView] = useState('heatmap'); // 'heatmap' or 'mask'

    if (!diagnosis || (!diagnosis.heatmap_base64 && !diagnosis.mask_base64)) return null;

    return (
        <div className="card" style={{ flex: 1 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <h2 className="card-title" style={{ marginBottom: 0 }}>
                    <Layers size={20} /> Explainable AI Overlay
                </h2>

                <div style={{ display: 'flex', gap: '0.5rem', background: 'var(--bg-color)', padding: '0.25rem', borderRadius: '8px' }}>
                    <button
                        onClick={() => setView('heatmap')}
                        style={{
                            border: 'none', background: view === 'heatmap' ? 'white' : 'transparent',
                            padding: '0.5rem 1rem', borderRadius: '6px', fontSize: '0.85rem', fontWeight: 600,
                            boxShadow: view === 'heatmap' ? 'var(--shadow-sm)' : 'none', cursor: 'pointer',
                            color: view === 'heatmap' ? 'var(--primary)' : 'var(--text-muted)', transition: 'all 0.2s'
                        }}
                    >
                        Grad-CAM Heatmap
                    </button>
                    <button
                        onClick={() => setView('mask')}
                        style={{
                            border: 'none', background: view === 'mask' ? 'white' : 'transparent',
                            padding: '0.5rem 1rem', borderRadius: '6px', fontSize: '0.85rem', fontWeight: 600,
                            boxShadow: view === 'mask' ? 'var(--shadow-sm)' : 'none', cursor: 'pointer',
                            color: view === 'mask' ? 'var(--text-main)' : 'var(--text-muted)', transition: 'all 0.2s'
                        }}
                    >
                        U-Net Lesion Mask
                    </button>
                </div>
            </div>

            <div className="img-preview-container" style={{ flex: 1, minHeight: '300px', backgroundColor: '#e2e8f0' }}>
                {view === 'heatmap' && diagnosis.heatmap_base64 && (
                    <img src={`data:image/jpeg;base64,${diagnosis.heatmap_base64}`} alt="Grad-CAM Heatmap" />
                )}
                {view === 'mask' && diagnosis.mask_base64 && (
                    <img src={`data:image/jpeg;base64,${diagnosis.mask_base64}`} alt="Lesion Segmentation Mask" />
                )}
            </div>

            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '1rem', textAlign: 'center' }}>
                {view === 'heatmap'
                    ? "Highlights regions of highest importance for the model's decision."
                    : "Highlights potential microaneurysms and exudates detected by the segmentation network."}
            </p>
        </div>
    );
};

export default HeatmapViewer;
