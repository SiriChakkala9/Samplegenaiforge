import React, { useRef, useState } from 'react';
import { UploadCloud, Image as ImageIcon, X } from 'lucide-react';

const ImageUpload = ({ onUpload, isProcessing, file }) => {
    const [dragActive, setDragActive] = useState(false);
    const [previewUrl, setPreviewUrl] = useState(null);
    const inputRef = useRef(null);

    const handleDrag = function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === "dragenter" || e.type === "dragover") {
            setDragActive(true);
        } else if (e.type === "dragleave") {
            setDragActive(false);
        }
    };

    const processFile = (selectedFile) => {
        if (selectedFile && selectedFile.type.startsWith('image/')) {
            const url = URL.createObjectURL(selectedFile);
            setPreviewUrl(url);
            onUpload(selectedFile);
        }
    };

    const handleDrop = function (e) {
        e.preventDefault();
        e.stopPropagation();
        setDragActive(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            processFile(e.dataTransfer.files[0]);
        }
    };

    const handleChange = function (e) {
        e.preventDefault();
        if (e.target.files && e.target.files[0]) {
            processFile(e.target.files[0]);
        }
    };

    const clearImage = () => {
        setPreviewUrl(null);
        if (inputRef.current) inputRef.current.value = "";
        onUpload(null);
    };

    return (
        <div className="card" style={{ flex: 1 }}>
            <h2 className="card-title">Retinal Scan Upload</h2>

            {!previewUrl ? (
                <div
                    className={`upload-area ${dragActive ? 'drag-active' : ''}`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    onClick={() => inputRef.current?.click()}
                >
                    <UploadCloud className="upload-icon" />
                    <div>
                        <p style={{ fontWeight: 600, color: 'var(--text-main)', marginBottom: '0.25rem' }}>
                            Upload Fundus Image
                        </p>
                        <p className="upload-text">Drag and drop or click to select</p>
                    </div>
                    <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Supported: JPG, PNG • Max size: 10MB</p>
                    <input
                        ref={inputRef}
                        type="file"
                        accept="image/*"
                        style={{ display: 'none' }}
                        onChange={handleChange}
                    />
                </div>
            ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', height: '100%' }}>
                    <div className="img-preview-container" style={{ flex: 1 }}>
                        <img src={previewUrl} alt="Retinal scan preview" />
                        {!isProcessing && (
                            <button
                                onClick={clearImage}
                                style={{
                                    position: 'absolute', top: '10px', right: '10px',
                                    background: 'rgba(0,0,0,0.5)', color: 'white',
                                    border: 'none', borderRadius: '50%', padding: '0.5rem',
                                    cursor: 'pointer'
                                }}>
                                <X size={16} />
                            </button>
                        )}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', background: 'var(--bg-color)', borderRadius: 'var(--radius-md)' }}>
                        <ImageIcon size={20} color="var(--primary)" />
                        <span style={{ fontSize: '0.9rem', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {file?.name || "Image uploaded"}
                        </span>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ImageUpload;
