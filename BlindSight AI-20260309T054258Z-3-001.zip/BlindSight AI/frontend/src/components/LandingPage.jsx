import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, ShieldCheck, Zap, Activity, BrainCircuit } from 'lucide-react';

const LandingPage = () => {
    const navigate = useNavigate();

    return (
        <div className="landing-container">
            {/* Navigation */}
            <nav className="landing-nav">
                <div className="logo">
                    <Eye size={28} color="var(--primary)" />
                    <span style={{ fontWeight: 700, fontSize: '1.25rem' }}>BlindSight AI</span>
                </div>
                <button className="btn nav-btn" onClick={() => navigate('/dashboard')}>
                    Go to Dashboard
                </button>
            </nav>

            {/* Hero Section */}
            <section className="hero-section">
                <div className="hero-content">
                    <div className="badge info" style={{ marginBottom: '1.5rem', alignSelf: 'flex-start' }}>
                        <ShieldCheck size={16} style={{ marginRight: '6px' }} /> Transformative Medical AI
                    </div>
                    <h1 className="hero-title">
                        Intelligent, Explainable & Privacy-Preserving
                        <br /><span className="gradient-text">Blindness Detection</span>
                    </h1>
                    <p className="hero-subtitle">
                        A powerful multimodal clinical platform utilizing Vision Transformers, U-Net Segmentation, and advanced LLM-powered diagnostics to detect Diabetic Retinopathy and estimate blindness progression.
                    </p>
                    <div className="hero-actions">
                        <button className="btn cta-btn" onClick={() => navigate('/dashboard')}>
                            Launch Clinical Dashboard
                        </button>
                        <a href="#features" className="secondary-link">Explore Features ↓</a>
                    </div>
                </div>

                <div className="hero-visual">
                    <div className="abstract-ai-ball"></div>
                    <div className="glass-card">
                        <Activity size={24} color="var(--success)" />
                        <div>
                            <h4>Diabetic Retinopathy</h4>
                            <p>Positive Detection — 98.4% Confidence</p>
                        </div>
                    </div>
                    <div className="glass-card lower-card">
                        <BrainCircuit size={24} color="var(--primary)" />
                        <div>
                            <h4>Explainable AI Flow</h4>
                            <p>Grad-CAM and U-Net Overlay Active</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* Features Grid */}
            <section id="features" className="features-section">
                <div className="section-header">
                    <h2>Core Clinical Capabilities</h2>
                    <p>Built for real-world ophthalmology deployments</p>
                </div>

                <div className="features-grid">
                    <div className="feature-card">
                        <div className="feature-icon"><Eye /></div>
                        <h3>ViT Feature Extraction</h3>
                        <p>Captures deeply contextual global relationships in the retinal fundus scan using advanced Vision Transformer heads.</p>
                    </div>
                    <div className="feature-card">
                        <div className="feature-icon"><Activity /></div>
                        <h3>Multi-Task Diagnostics</h3>
                        <p>Simultaneously predicts Binary DR, five-stage severity levels, and estimates numeric blindness risk scores instantly.</p>
                    </div>
                    <div className="feature-card">
                        <div className="feature-icon"><BrainCircuit /></div>
                        <h3>Explainable Grad-CAM</h3>
                        <p>Transparency first. View exactly which regions of the retina heavily influenced the AI’s diagnostic conclusion.</p>
                    </div>
                    <div className="feature-card">
                        <div className="feature-icon"><Zap /></div>
                        <h3>LLM Clinical Reasoning</h3>
                        <p>Translates complex algorithmic output probabilities into human-readable medical reports and patient recommendations.</p>
                    </div>
                </div>
            </section>

            {/* Footer */}
            <footer className="landing-footer">
                <p>&copy; 2026 BlindSight AI Diagnostics System. Built for next-generation Telemedicine.</p>
            </footer>
        </div>
    );
};

export default LandingPage;
