import os
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

class PDFService:
    def generate_report(self, diagnosis_data: dict, llm_interpretation: str, output_path: str = "report.pdf") -> str:
        """Generates a PDF medical report using ReportLab"""
        c = canvas.Canvas(output_path, pagesize=letter)
        width, height = letter
        
        # Header
        c.setFont("Helvetica-Bold", 20)
        c.drawString(50, height - 50, "MedVision AI - Clinical Ophthalmology Report")
        
        c.setFont("Helvetica", 12)
        c.drawString(50, height - 80, "Patient ID: MV-001294")
        c.drawString(50, height - 100, "Date: 2026-02-27")
        
        # Diagnostics
        c.setFont("Helvetica-Bold", 14)
        c.drawString(50, height - 140, "Diagnostic Output:")
        
        c.setFont("Helvetica", 12)
        start_y = height - 160
        c.drawString(50, start_y, f"Diabetic Retinopathy Present: {'Yes' if diagnosis_data.get('dr_present') else 'No'}")
        c.drawString(50, start_y - 20, f"Severity: {diagnosis_data.get('severity')}")
        c.drawString(50, start_y - 40, f"Blindness Risk Score: {diagnosis_data.get('risk_score')}/100")
        c.drawString(50, start_y - 60, f"Progression Trend: {diagnosis_data.get('progression_trend')}")
        
        # Interpretation
        c.setFont("Helvetica-Bold", 14)
        c.drawString(50, start_y - 100, "Clinical Interpretation & Reasoning:")
        
        c.setFont("Helvetica", 11)
        text_object = c.beginText(50, start_y - 120)
        
        # Handle word wrap simply for demo
        for line in llm_interpretation.split('\n'):
            # simple wrap logic for report
            words = line.split(' ')
            current_line = ""
            for word in words:
                if len(current_line) + len(word) < 90:
                    current_line += word + " "
                else:
                    text_object.textLine(current_line)
                    current_line = word + " "
            text_object.textLine(current_line)
            
        c.drawText(text_object)
        
        # Footer
        c.setFont("Helvetica-Oblique", 10)
        c.drawString(50, 50, "Note: This is an AI-generated report. Final diagnosis must be confirmed by a licensed professional.")
        
        c.save()
        return output_path

pdf_service = PDFService()
