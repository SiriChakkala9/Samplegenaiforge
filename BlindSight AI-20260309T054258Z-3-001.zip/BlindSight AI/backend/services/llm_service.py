import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

class LLMService:
    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.client = OpenAI(api_key=self.api_key) if self.api_key else None

    def generate_clinical_interpretation(self, diagnosis_data: dict) -> str:
        prompt = f"""
        Act as an expert ophthalmologist. Based on the following AI analysis of a retinal fundus image, 
        provide a short, human-readable clinical interpretation for the patient, including explainability reasoning and a final recommendation.
        
        Data:
        - DR Present: {"Yes" if diagnosis_data.get('dr_present') else "No"}
        - Severity: {diagnosis_data.get('severity')}
        - Blindness Risk Score: {diagnosis_data.get('risk_score', 0)}/100
        - Progression Trend: {diagnosis_data.get('progression_trend')}
        
        Structure your response with:
        1. Clinical Interpretation
        2. Explainability Summary
        3. Recommendation
        Keep it professional, concise, and easy to understand.
        """
        
        if self.client:
            try:
                response = self.client.chat.completions.create(
                    model="gpt-4",
                    messages=[{"role": "system", "content": "You are a clinical AI assistant."},
                              {"role": "user", "content": prompt}],
                    max_tokens=300
                )
                return response.choices[0].message.content
            except Exception as e:
                print(f"OpenAI API error: {e}")
        
        # Local Fallback / Mock
        return self._mock_interpretation(diagnosis_data)

    def _mock_interpretation(self, data: dict) -> str:
        severity = data.get('severity', 'Unknown')
        risk = data.get('risk_score', 0)
        
        interp = f"The AI analysis indicates **{severity} Diabetic Retinopathy**.\n\n"
        interp += "**Explainability Summary:** The model's attention maps highlight microaneurysms and potential exudates consistent with early to moderate vascular damage.\n\n"
        interp += f"**Progression:** The temporal analysis shows a '{data.get('progression_trend')}' trend in disease severity over simulated prior visits.\n\n"
        
        if risk > 70:
            interp += "**Recommendation:** Urgent Referral. Immediate consultation with an ophthalmologist is required to prevent severe vision loss."
        elif risk > 30:
            interp += "**Recommendation:** Routine Monitoring. Specialist consultation is recommended within 3 months."
        else:
            interp += "**Recommendation:** Annual screening. Maintain blood sugar control and attend regular checkups."
            
        return interp

llm_service = LLMService()
