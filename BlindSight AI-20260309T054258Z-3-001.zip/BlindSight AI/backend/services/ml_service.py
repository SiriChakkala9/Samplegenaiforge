import torch
import numpy as np
import cv2
import base64
from backend.models.architectures import ViTFeatureExtractor, UNetLesionDetector, LSTMPredictor

class MLService:
    def __init__(self):
        # Initialize mock models
        self.vit = ViTFeatureExtractor()
        self.unet = UNetLesionDetector()
        self.lstm = LSTMPredictor()
        
    def analyze_image(self, image_array: np.ndarray) -> dict:
        """Runs the full ML pipeline on a processed image numpy array"""
        
        # 1. Prepare tensor (mock)
        dummy_tensor = torch.rand(1, 3, 224, 224)
        
        # 2. Extract Features (ViT)
        features = self.vit(dummy_tensor)
        
        # 3. Lesion Detection (U-Net) -> Mask
        mask_tensor = self.unet(dummy_tensor)
        
        # 4. Multi-task Diagnosis (Mocked logic based on random features for demo)
        dr_present = bool(torch.rand(1).item() > 0.3)
        severity_levels = ["Mild", "Moderate", "Severe", "Proliferative"]
        severity = severity_levels[np.random.randint(0, len(severity_levels))] if dr_present else "None"
        risk_score = int(np.random.uniform(10, 95)) if dr_present else int(np.random.uniform(1, 15))
        
        # 5. Progression Prediction (LSTM)
        # Mock time series features (e.g. 3 past visits)
        temporal_tensor = torch.rand(1, 3, 768)
        progression_val = self.lstm(temporal_tensor).item()
        progression_trend = "Increasing" if progression_val > 0.6 else "Stable" if progression_val > 0.3 else "Slight Decrease"
        
        # 6. Generate Explainability Heatmap (Grad-CAM mock)
        heatmap_b64 = self._generate_mock_heatmap(image_array)
        mask_b64 = self._generate_mock_mask(image_array)
        
        return {
            "dr_present": dr_present,
            "severity": severity,
            "risk_score": risk_score,
            "progression_trend": progression_trend,
            "heatmap_base64": heatmap_b64,
            "mask_base64": mask_b64
        }
        
    def _generate_mock_heatmap(self, image_array: np.ndarray) -> str:
        """Generates a mock Grad-CAM heatmap overlayed on the original image"""
        h, w = image_array.shape[:2]
        heatmap = np.uint8(255 * np.random.rand(h, w))
        heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
        result = cv2.addWeighted(image_array, 0.6, heatmap, 0.4, 0)
        
        _, buffer = cv2.imencode('.jpg', result)
        return base64.b64encode(buffer).decode('utf-8')
        
    def _generate_mock_mask(self, image_array: np.ndarray) -> str:
        """Generates a mock lesion mask overlay"""
        h, w = image_array.shape[:2]
        zeros = np.zeros((h, w, 3), dtype=np.uint8)
        
        # Draw some random red circles representing hemorrhages/microaneurysms
        for _ in range(np.random.randint(3, 10)):
            cx, cy = np.random.randint(0, w), np.random.randint(0, h)
            radi = np.random.randint(2, 8)
            cv2.circle(zeros, (cx, cy), radi, (0, 0, 255), -1)
            
        result = cv2.addWeighted(image_array, 0.8, zeros, 0.8, 0)
        _, buffer = cv2.imencode('.jpg', result)
        return base64.b64encode(buffer).decode('utf-8')

ml_service = MLService()
